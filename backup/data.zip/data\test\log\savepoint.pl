'org.prolobjectlink.db.savepoint.SavePointRecord'('org.prolobjectlink.db.OperationType'('BEGIN',22),'org.prolobjectlink.db.OperationType'('CLOSE',2),'org.prolobjectlink.domain.geometry.Point'(Idp,X,Y),'org.prolobjectlink.domain.geometry.Point'(a,3,14),1549147212560).

'org.prolobjectlink.db.savepoint.SavePointRecord'('org.prolobjectlink.db.OperationType'('BEGIN',22),'org.prolobjectlink.db.OperationType'('CLOSE',2),'org.prolobjectlink.domain.geometry.Point'(Idp,X,Y),'org.prolobjectlink.domain.geometry.Point'(a,3,14),1549147555414).

'org.prolobjectlink.db.savepoint.SavePointRecord'('org.prolobjectlink.db.OperationType'('BEGIN',22),'org.prolobjectlink.db.OperationType'('CLOSE',2),'org.prolobjectlink.domain.geometry.Point'(Idp,X,Y),'org.prolobjectlink.domain.geometry.Point'(a,3,14),1549148057527).

